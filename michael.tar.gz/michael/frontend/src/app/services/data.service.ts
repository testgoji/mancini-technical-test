import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Todo } from '../Todo';

const httpOptions = {
  headers: new HttpHeaders({'Content-Type': 'application/json'})
};

@Injectable()
export class DataService {

  constructor(private http: HttpClient) { }

  getTodos() {
    console.log('get');
    return this.http.get('http://localhost:3000/api', httpOptions);
  }

  addTodos(newTodo: Todo) {
    console.log(Todo);
    return this.http.post('http://localhost:3000/api', newTodo, httpOptions);
  }

  deleteTodo(id) {
    return this.http.delete('http://localhost:3000/api/' + id, httpOptions);
  }

  updateTodo(updated: Todo) {
    return this.http.put('http://localhost:3000/api/' + updated._id, updated, httpOptions);
  }

}
