import { Component, OnInit } from '@angular/core';
import { DataService } from './services/data.service';
import { Todo } from './Todo';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  todos;
  testTitle;

  constructor(public data: DataService) {}

  ngOnInit() {
    // this.getTodos();
  }

  getTodos() {
    this.data.getTodos().subscribe(items => {
      this.todos = items;
    });
    console.log(this.todos);
  }

  addTodo(form) {
    let newTodo: Todo = {
      title: this.testTitle
    };
    console.log(newTodo);
    form.resetForm();
    this.data.addTodos(newTodo).subscribe(item => {
      this.getTodos();
    });
  }


}
