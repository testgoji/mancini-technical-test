export class Todo {
    _id?: String;
    title: String;
    completed?: Boolean;
}
