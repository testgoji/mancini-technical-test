const express = require('express');
const router = express.Router();

const Todo = require('../models/todo-model');

router.get('/', (req, res) => {
    Todo.find((err, items) => {
        if (err) {
            res.json(err);
        } else {
            res.json(items);
            console.log(items);
        }
    });
});

router.post('/', (req, res) => {
    let newTodo = new Todo({
        title: req.body.title
    });

    newTodo.save((err, result) => {
        if (err) {
            res.json(err);
        } else {
            res.send({msg: 'Item added successfully'});
        }
    });
});

router.delete('/:id', (req, res) => {
    Todo.remove({
        _id: req.params.id
    }, (err, result) => {
        if (err) {
            res.json(err);
        } else {
            res.json(result);
        }
    });
});

router.put('/:id', (req, res) => {
    Todo.findOneAndUpdate({
        _id: req.params.id
    }, {
        $set: {
            title: req.body.title,
            completed: req.body.completed
        }
    }, (err, result) => {
        if (err) {
            res.json(err);
        } else {
            res.json(result);
        }
    });
});

module.exports = router;