const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
// const hbs = require('hbs');
const cors = require('cors');

const crud = require('./routes/crud');

var app = express();

mongoose.Promise = global.Promise;
mongoose.connect('mongodb://mikey:agonyvii@ds119064.mlab.com:19064/goji');
mongoose.connection.on('connected', () => {
    console.log('~~ Mongo :) ~~');
});
mongoose.connection.on('error', (err) => {
    console.log(err);
});

// app.set('view engine', 'hbs');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));
app.use(cors());

app.use('/api', crud);

app.get('/', (req, res) => {
    // res.render('home.hbs', {
    //     pageTitle: 'Home Page'
    // });
    res.send('node page');
});

const port = 3000;
app.listen(3000, () => console.log(`Server started on port ${port}`));